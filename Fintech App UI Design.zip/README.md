
  # Fintech App UI Design

  This is a code bundle for Fintech App UI Design. The original project is available at https://www.figma.com/design/dH15jK6zpn2V6oEYkJyCp1/Fintech-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  